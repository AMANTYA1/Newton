# NEWTON ɢʀᴏᴜᴘ ʙᴏᴛ
<p align="center">
    <a href="https://github.com/KUZUKIbots/KUZUKI/stargazers"><img src="https://img.shields.io/github/stars/kuzukibots/kuzuki?label=Stars&style=flat-square&logo=github&color=F10070" alt="Stars" /></a>
</p>
<p align="center">
    <a href="https://github.com/kuzukibots/kuzuki"> <img src="https://img.shields.io/github/repo-size/KUZUKibots/kuzuki?color=orange&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/kuzukibots/kuzuki/commits/prince"> <img src="https://img.shields.io/github/last-commit/kuzukibots/kuzuki?color=blue&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/kuzukibots/kuzuki/issues"> <img src="https://img.shields.io/github/issues/kuzukibots/kuzuki?color=blueviolet&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/kuzukibots/kuzuki/network/members"> <img src="https://img.shields.io/github/forks/kuzukibots/kuzuki?color=red&logo=github&logoColor=green&style=for-the-badge" /></a>  
    <a href="https://pypi.org/project/Telethon/"> <img src="https://img.shields.io/pypi/v/telethon?color=yellow&label=telethon&logo=python&logoColor=green&style=for-the-badge" /></a>
</p>

<p align="center">
  <img src="https://te.legra.ph/file/0324b9d528d6b1393782f.jpg">
</p>

## ʜᴏᴡ ᴛᴏ ʜᴏꜱᴛ Netwon ?

- Hosting at Heroku
The easiest way to deploy this Bot
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/AMANTYA1/Mewtwo"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

- Hosting at Okteto
Second easiest way to deploy this bot
<p align="center">
<a href="https://cloud.okteto.com/deploy?repository=https://github.com/AMANTYA1/Mewtwo"><img src="https://img.shields.io/badge/Deploy%20To%20Okteto-informational?style=for-the-badge&logo=Okteto" width="200""/></p></a>

```
# REQUIRED VARS SUR

- OWNER_ID = YOUR ID SUR
- OWNER_USERNAME = YOUR USERNAME
- SUDO_USER = YOUR SUDO USER
- SUPPORT_USER = YOUR SUPPORT USER ID
- WHITELIST_USER = YOUR WHITELISTD USER ID
- ENV = ANYTHING (DON'T CHANGE)
- DEL_CMDS = TRUE 
- KEMESSAGE_DUMP= EXP💡 " USE CHAT ID MUST PRIVATE " 
- ALLOW_EXCL = TRUE 
- TOKEN = YOUR BOT TOKEN SUR
- STRICT_GBAN = TRUE 
- PORT = 8443
```

``
Please note that if you are using Heroku, after build logs, you have to add add-ons yourself.
Choose heroku postegres and turn on dynos to start working.
``
# ᴘᴏɪɴᴛꜱ ᴛᴏ ɴᴏᴛᴇ

These code were made under GNU Licence so anybody can use this code to make their own bot.
I will be very thankful if you will give a small credit for this codes in your projects. If you are 
forking this repo, it's fine !
If you are creating your own repo with the help of our codes, don't forget to give credit. 

Newton can be found on Telegram [here]().

# ꜱᴜᴘᴘᴏʀᴛ

<a href="https://t.me/BOTDUNIYAXD"> <img src="https://img.shields.io/badge/Update-Channel-red?style=for-the-badge&logo=telegram" /></a> </p>

# ᴄʀᴇᴅɪᴛꜱ

- [Axel](https://github.com/AXELXDEV) ``Bot-Owner``
- [Null-Coder](https://github.com/AMANTYA1) ``Repo Creator``

_______

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)
