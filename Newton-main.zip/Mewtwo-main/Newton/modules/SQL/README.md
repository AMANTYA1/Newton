# jl rahi hai kya teri vro😞 we
