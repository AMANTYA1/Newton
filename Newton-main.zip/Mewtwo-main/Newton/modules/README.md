## All files are made for [Newton](https://github.com/AMANTYA1/Newton) officially inspired from many open source projects. Newton is also an open source project and anyone can use this codes.
 - Inspired from [Marie](https://github.com/PaulSonOfLars/tgbot) and [Anie Team](https://github.com/AnieTeam/AnieRobot).
 - Recoded all files by [Null-Coder](https://github.com/AMANTYA1).
 - Ported and managed by [Axel](https://github.com/AXELXDEV).

