# Netwon Is Simple Telethon dock and python codes made bot
